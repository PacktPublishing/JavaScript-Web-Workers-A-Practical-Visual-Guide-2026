// import the worker module
const { Worker } = require("worker_threads");

// a function to split our large original array (tasks) into evenely distributed ones for each worker
function allocateTasksEvenly(tasks, concurrentWorkers) {
    let splitTasksArray = [];
    for (let index = concurrentWorkers; index > 0; index--) {
        splitTasksArray.push(tasks.splice(0, Math.ceil(tasks.length / index)));
    }
    return splitTasksArray;
}

// our main function to run tasks via workers
function run(tasks, concurrentWorkers) {
    const tick = performance.now(); 
    let completedWorkers = 0; 

    const splitTasksArray = allocateTasksEvenly(tasks, concurrentWorkers);

    splitTasksArray.forEach( (task, i) => {
        let worker = new Worker("./worker.js");
        worker.postMessage(task);
        worker.on('message', () => {
            console.log(`Worker ${i} completed`);
            completedWorkers++;
            if(completedWorkers === concurrentWorkers) {
                console.log(`${concurrentWorkers} workers took ${performance.now() - tick} ms`);
                process.exit(); // lets stop Node running, as we are done with all tasks
            }
        })
    })
}

// create synthetic (false) heavy CPU tasks
const tasks = Array.from({
    length: 50
}, () => 1e9); // [1000000000, 10000000000, etc]

// run tasks off Node's main JS thread, specifying how many workers you want to perform the heavy-tasks
run(tasks, 4);

