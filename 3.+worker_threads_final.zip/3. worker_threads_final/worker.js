const { parentPort } = require("worker_threads");

parentPort.on("message", (heavyTask) => {
    
    // simulating a heavy amount of tasks
    for (const task of heavyTask) {
        let count = 0; 
        for (let index = 0; index < task; index++) {
            count++;
        }
    };

    parentPort.postMessage("done");

})
