// all code here, will run off the main thread. In other words, code here will have its own JS environment, memory heap and call stack. 

self.addEventListener("message", (e) => {
    console.log("WW got data: ", e.data);
    let i = 0; 
    // lets count to 10bn, to simulate a long CPU task
    while (i < 1e10) {
        i++;
    }
    self.postMessage("Heavy task done!");
    // close our worker? 
    self.close(); // graceful closure after its done its tasks
});